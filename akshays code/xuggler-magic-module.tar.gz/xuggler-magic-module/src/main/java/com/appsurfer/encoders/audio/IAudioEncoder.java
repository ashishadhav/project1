package com.appsurfer.encoders.audio;

/**
 * User: akshay
 * Date: 9/21/12
 * Time: 2:02 PM
 */
public interface IAudioEncoder {
    public boolean write(byte[] buffer);
    public void printStreamInfo();
}
