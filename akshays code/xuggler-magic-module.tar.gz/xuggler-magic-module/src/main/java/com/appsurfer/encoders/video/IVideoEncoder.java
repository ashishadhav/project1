package com.appsurfer.encoders.video;

/**
 * User: akshay
 * Date: 9/25/12
 * Time: 1:06 PM
 */
public interface IVideoEncoder {
    public void streamVideo(String filePath);
}
