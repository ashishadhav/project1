package com.appsurfer.encoders.video;

import com.appsurfer.fbsnapper.PasswordGetter;
import com.appsurfer.fbsnapper.Snapper;
import com.appsurfer.fbsnapper.Status;
import com.xuggle.xuggler.*;
import com.xuggle.xuggler.video.ConverterFactory;
import com.xuggle.xuggler.video.IConverter;
import java.awt.image.BufferedImage;

/**
 * RTMP encoder class basically writes on the RTMP container that is opened by RED5 Server
 */
public final class RTMPEncoder {


    // Some configuration variables
    private static final int VIDEO_HEIGHT = 480;
    private static final int VIDEO_WIDTH = 320;
    private static final IRational FRAME_RATE = IRational.make(22, 1);

    // Xuggler related structures
    private IContainer mRTMPContainer;
    private IContainerFormat mRTMPContainerFormat;
    private IStream mRTMPStream;
    private IStreamCoder mRTMPStreamCoder;


    // Snapper object for getting images
    private Snapper mSnapper;

    public RTMPEncoder(String serverName, int port, String password, String streamName) {
        // connect snapper to the asked instance
        mSnapper = new Snapper(serverName, port, new PasswordGetter(password));

        if(mSnapper.getStatus()==Status.DISCONNECTED)
            throw new IllegalStateException("Could not connect to the server");

        System.out.println("Connected to host");

        mRTMPContainer = IContainer.make();
        mRTMPContainer.setInputBufferLength(0);

        mRTMPContainerFormat = IContainerFormat.make();
        mRTMPContainerFormat.setOutputFormat("flv", "rtmp://serverName/" + streamName, null);

        int retVal = mRTMPContainer.open("rtmp://serverName/"+streamName, IContainer.Type.WRITE, mRTMPContainerFormat);
        if (retVal < 0) {
            System.out.println("Could not open output container for live stream");
            System.exit(1);
        }
        System.out.println("Connected to the stream");

        // Add our stream to container
        mRTMPStream = mRTMPContainer.addNewStream(ICodec.ID.CODEC_ID_FLV1);
        mRTMPStreamCoder = mRTMPStream.getStreamCoder();
        mRTMPStreamCoder.setNumPicturesInGroupOfPictures(15);
        mRTMPStreamCoder.setBitRate(25000);
        mRTMPStreamCoder.setBitRateTolerance(9000);
        mRTMPStreamCoder.setPixelType(IPixelFormat.Type.YUV420P);
        mRTMPStreamCoder.setHeight(VIDEO_HEIGHT);
        mRTMPStreamCoder.setWidth(VIDEO_WIDTH);
        System.out.println("[ENCODER] video size is " + VIDEO_WIDTH + "x" + VIDEO_HEIGHT);
        mRTMPStreamCoder.setFlag(IStreamCoder.Flags.FLAG_QSCALE, true);
        mRTMPStreamCoder.setGlobalQuality(0);
        mRTMPStreamCoder.setFrameRate(FRAME_RATE);
        mRTMPStreamCoder.setTimeBase(IRational.make(FRAME_RATE.getDenominator(), FRAME_RATE.getNumerator()));
    }

    public void open(){
        mRTMPStreamCoder.open(IMetaData.make(), IMetaData.make());
        // start with writing header
        mRTMPContainer.writeHeader();
        long firstTimeStamp = System.currentTimeMillis();
        long lastTimeStamp = -1;
        try {
            int i =0 ;
            while (true) {
                //long iterationStartTime = System.currentTimeMillis();
                long now = System.currentTimeMillis();
                //convert it for Xuggler
                BufferedImage currentScreenshot =  convertToType(mSnapper.getFbImage(), BufferedImage.TYPE_3BYTE_BGR);
                //start the encoding process
                IPacket packet = IPacket.make();
                IConverter converter = ConverterFactory.createConverter(currentScreenshot, IPixelFormat.Type.YUV420P);
                long timeStamp = (now - firstTimeStamp) * 1000;
                IVideoPicture outFrame = converter.toPicture(currentScreenshot, timeStamp);
                //TODO remove if this is not needed
                if (i == 0) {
                    //make first frame keyframe
                    outFrame.setKeyFrame(true);
                    i++;
                }
                outFrame.setQuality(0);
                mRTMPStreamCoder.encodeVideo(packet, outFrame, 0);
                outFrame.delete();
                if (packet.isComplete()) {
                    mRTMPContainer.writePacket(packet);
                    //System.out.println("[ENCODER] writing packet of size " + packet.getSize() + " for elapsed time " + ((timeStamp - lastTimeStamp) / 1000));
                    lastTimeStamp = timeStamp;
                }
                try {
                    // sleep for framerate milliseconds
                    Thread.sleep(Math.max((long) (1000 / FRAME_RATE.getDouble()) - (System.currentTimeMillis() - now), 0));
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void close(){
        mRTMPContainer.writeTrailer();
    }

    /**
     * Convert a {@link BufferedImage} of any type, to {@link
     * BufferedImage} of a specified type.  If the source image is the
     * same type as the target type, then original image is returned,
     * otherwise new image of the correct type is created and the content
     * of the source image is copied into the new image.
     *
     * @param sourceImage the image to be converted
     * @param targetType the desired BufferedImage type
     *
     * @return a BufferedImage of the specifed target type.
     *
     * @see BufferedImage
     */

    public BufferedImage convertToType(BufferedImage sourceImage,
                                       int targetType)
    {
        BufferedImage image;
        // if the source image is already the target type, return the source image
        if (sourceImage.getType() == targetType)
            image = sourceImage;
            // otherwise create a new image of the target type and draw the new
            // image
        else
        {
            image = new BufferedImage(sourceImage.getWidth(), sourceImage.getHeight(),
                    targetType);
            image.getGraphics().drawImage(sourceImage, 0, 0, null);
        }
        return image;
    }
}