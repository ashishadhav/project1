package com.appsurfer;

import com.appsurfer.encoders.video.RTMPEncoder;

/**
 * Console entry-point for xuggler module
 * User: Akshay Deo
 * Date: 10/3/12
 * Time: 11:22 AM
 */
public class Main {
    public static void main(String[] args){
        if(args.length < 4){
            System.err.println("<server_name> <port number> <password> <stream_name>");
            return;
        }
        RTMPEncoder coder = new RTMPEncoder(args[0],Integer.parseInt(args[1]), args[2], args[3]);
        coder.open();
        coder.close();
    }
}
