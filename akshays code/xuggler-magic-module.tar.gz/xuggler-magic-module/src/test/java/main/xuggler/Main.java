package main.xuggler;

import com.appsurfer.encoders.video.RTMPEncoder;

/**
 * User: akshay
 * Date: 9/21/12
 * Time: 1:56 PM
 */
public class Main {
    public static void main(String[] args){
        new Thread(new Runnable() {
            @Override
            public void run() {
                RTMPEncoder coder = new RTMPEncoder("gharat.appsurfer.com",9000,"amd3116","myapp/test/teststream");
                coder.open();
                coder.close();
            }
        }).start();

    }
}
