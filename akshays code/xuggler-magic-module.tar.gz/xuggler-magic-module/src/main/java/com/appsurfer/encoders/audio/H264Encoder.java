package com.appsurfer.encoders.audio;

import com.xuggle.xuggler.*;

/**
 * User: akshay
 * Date: 9/21/12
 * Time: 2:04 PM
 */
public class H264Encoder implements IAudioEncoder{

    private IContainer mContainer;
    private IStream mStream;
    private ICodec mH264Codec = ICodec.findEncodingCodec(ICodec.ID.CODEC_ID_H264);
    private IStreamCoder mStreamCoder;

    public H264Encoder(String url){
        //Create and open container
        mContainer = IContainer.make();
        if(mContainer.open(url, IContainer.Type.WRITE, null) < 0)
            throw new IllegalStateException("Error in creating container");
        //Create a stream coder for H264

        mStreamCoder = IStreamCoder.make(IStreamCoder.Direction.ENCODING, mH264Codec);

        mStreamCoder.setChannels(1);
        mStreamCoder.setSampleRate(22050);
        mStreamCoder.setBitRate(64000);
        mStreamCoder.setTimeBase(IRational.make(1,1000));
        //Create a new stream with H264 codec and get the reference
        mStream = mContainer.addNewStream(mStreamCoder);
        //Write header onto it
        if(mStreamCoder.open(IMetaData.make(),IMetaData.make())< 0)
            throw new IllegalStateException("Could not open stream coder");
    }


    @Override
    public boolean write(byte[] buffer) {
        return false;  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public void printStreamInfo() {
        System.out.println("Stream info " + mStream.getMetaData());
    }
}
